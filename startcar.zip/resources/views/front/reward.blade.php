@include('front.layout.header2')



<!-- Pagewrap Start Here -->
<div class="content">
    <!--  Banner Start here -->
    <section class="book-ride-banner inner-banner">
        <div class="banner-box">
            <h1><span>miles </span>rewards</h1>

        </div>
    </section>
    <!--  Banner End here -->

    <!-- Search Section Start here -->
    <div class="col">
        <section class="search-section">
            <div class="container">
                <div class="content">

                    <!-- Tab content -->
                    <div class="wrapper_tabcontent">
                        <div id="upcoming" class="tabcontent active">
                            <div class="tab-sec left" id="">

                                <div class="row">
                                    <table class="table table-striped">
                                        <tr>
                                            <td class=" bg-danger text-center">
                                                <h4 style="color:#fff; font-weight:600; font-size:24px">Total Reward
                                                    Ponits Earned : 1360</h4>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="row">
                                    <table class="table table-striped table-hover table-dark ">
                                        <tr>
                                            <td>7278101
                                                <!--<span>new</span>-->
                                                <div class="smalll"><small>Created: Jul 16, 2020 8:52 AM</small></div>
                                            </td>
                                            <td>Nov 27, 2021 11:30 PM<div class="smalll"><small>Return: </small>Mar 26,
                                                    2022 2:00 PM</div>
                                            </td>
                                            <td><small>From :</small> Ludhiana<div class="smalll"><small>To :</small>
                                                    Delhi</div>
                                            </td>
                                            <td>680 <div class="smalll"><small>KMs Traveled</small></div>
                                            </td>
                                            <td class=" bg-success text-center">680 <div class="smalll"><small>Reward
                                                        Points Earned</small></div>
                                            </td>
                                        </tr>
                                        <tr>

                                        </tr>
                                    </table>
                                </div>
                                <div class="row">
                                    <table class="table table-striped table-hover table-dark ">
                                        <tr>
                                            <td>7278101
                                                <!--<span>new</span>-->
                                                <div class="smalll"><small>Created: Jul 16, 2020 8:52 AM</small></div>
                                            </td>
                                            <td>Nov 27, 2021 11:30 PM<div class="smalll"><small>Return: </small>Mar 26,
                                                    2022 2:00 PM</div>
                                            </td>
                                            <td><small>From :</small> Ludhiana<div class="smalll"><small>To :</small>
                                                    Delhi</div>
                                            </td>
                                            <td>680 <div class="smalll"><small>KMs Traveled</small></div>
                                            </td>
                                            <td class=" bg-success text-center">680 <div class="smalll"><small>Reward
                                                        Points Earned</small></div>
                                            </td>
                                        </tr>
                                        <tr>

                                        </tr>
                                    </table>
                                </div>
                            </div>


                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- Search Section End here -->



    <div class="clearfix"></div>




@include('front.layout.footer')