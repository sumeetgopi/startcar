@include('front.layout.header2')


<!-- Pagewrap Start Here -->
<div class="content">
    <!--  Banner Start here -->
    <section class="book-ride-banner inner-banner">
        <div class="banner-box">
            <h1><span>FAQ</span>s</h1>

        </div>
    </section>
    <!--  Banner End here -->

    <!-- Search Section Start here -->
    <div class="col">
        <section class="search-section">
            <div class="container">
                <div class="content">

                    <!-- Tab content -->
                    <div class="wrapper_tabcontent">
                        <div id="pending" class="tabcontent active">
                            <div class="tab-sec left no-mar-bot" id="">
                                <!--faq start -->
                                <div class="row">
                                    <table class="table table-striped table-hover table-light ">
                                        <tr>
                                            <td>
                                                <div id="accordion">
                                                    <div class="">
                                                        <div class="" id="headingOne">
                                                            <h5 class="mb-0">
                                                                <a data-toggle="collapse" data-target="#collapseOne"
                                                                    aria-expanded="true"
                                                                    aria-controls="collapseOne"><strong>What is
                                                                        Jeetii</strong> <i
                                                                        class="details rightt"></i></a>
                                                            </h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>

                                    <div>
                                        <div id="collapseOne" class="collapse hide" aria-labelledby="headingOne"
                                            data-parent="#accordion" style="background:#fff">


                                            <div class="faq">
                                                <div class="col-md-12">
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                                    ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--faq end -->


                                <!--faq start -->
                                <div class="row">
                                    <table class="table table-striped table-hover table-light ">
                                        <tr>
                                            <td>
                                                <div id="accordion">
                                                    <div class="">
                                                        <div class="" id="headingOne2">
                                                            <h5 class="mb-0">
                                                                <a data-toggle="collapse" data-target="#collapseOne2"
                                                                    aria-expanded="true"
                                                                    aria-controls="collapseOne"><strong>How does Jeetii
                                                                        work?</strong> <i
                                                                        class="details rightt"></i></a>
                                                            </h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>

                                    <div>
                                        <div id="collapseOne2" class="collapse hide" aria-labelledby="headingOne"
                                            data-parent="#accordion" style="background:#fff">


                                            <div class="faq">
                                                <div class="col-md-12">
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                                    ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--faq end -->

                                <!--faq start -->
                                <div class="row">
                                    <table class="table table-striped table-hover table-light ">
                                        <tr>
                                            <td>
                                                <div id="accordion">
                                                    <div class="">
                                                        <div class="" id="headingOne3">
                                                            <h5 class="mb-0">
                                                                <a data-toggle="collapse" data-target="#collapseOne3"
                                                                    aria-expanded="true"
                                                                    aria-controls="collapseOne"><strong>What are the
                                                                        benefits?</strong> <i
                                                                        class="details rightt"></i></a>
                                                            </h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>

                                    <div>
                                        <div id="collapseOne3" class="collapse hide" aria-labelledby="headingOne"
                                            data-parent="#accordion" style="background:#fff">


                                            <div class="faq">
                                                <div class="col-md-12">
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                                    ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--faq end -->


                                <!--faq start -->
                                <div class="row">
                                    <table class="table table-striped table-hover table-light ">
                                        <tr>
                                            <td>
                                                <div id="accordion">
                                                    <div class="">
                                                        <div class="" id="headingOne4">
                                                            <h5 class="mb-0">
                                                                <a data-toggle="collapse" data-target="#collapseOne4"
                                                                    aria-expanded="true"
                                                                    aria-controls="collapseOne"><strong>What are
                                                                        MilePoints?</strong> <i
                                                                        class="details rightt"></i></a>
                                                            </h5>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>

                                    <div>
                                        <div id="collapseOne4" class="collapse hide" aria-labelledby="headingOne"
                                            data-parent="#accordion" style="background:#fff">


                                            <div class="faq">
                                                <div class="col-md-12">
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
                                                    ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--faq end -->


                            </div>


                        </div>



                        <div id="past" class="tabcontent">
                            <div class="tab-sec left" id="">

                                <div class="route row">
                                    <div class="col-md-5"><span>From</span> <i class="fa fa-location-arrow locc"></i>
                                        Ambala <span>To</span> <i class="fa fa-location-arrow locc"></i> Delhi</div>

                                </div>

                                <div>Jul 10, 2020 12:00 PM <span>(118 km)</span></div>
                                <div>Transfer request <span>#7278116</span></div>

                                <div>&nbsp;</div>

                                <div id="accordion">
                                    <div class="card">
                                        <div class="card-header" id="headingOne">
                                            <h5 class="mb-0">
                                                <button class="btn btn-link" data-toggle="collapse"
                                                    data-target="#collapseTwo" aria-expanded="true"
                                                    aria-controls="collapseTwo">
                                                    Details <i class="details"></i>
                                                </button>
                                            </h5>
                                        </div>

                                        <div id="collapseTwo" class="collapse hide" aria-labelledby="headingOne"
                                            data-parent="#accordion">
                                            <div class="card-body row">
                                                <div class="col-md-6">
                                                    <div class="route"><span>Transfer date &amp; time</span><br>Jul 10,
                                                        2020 12:00 PM</div>
                                                    <div class="route"><span>No. of Passengers</span><br>2</div>
                                                    <div class="col-md-6">
                                                        <h4>Chosen Transport Type</h4>
                                                        <a class="nav-item nav-link chosen" id="nav-mini-tab2"
                                                            data-toggle="tab" href="#nav-sedan2" role="tab"
                                                            aria-controls="nav-sedan" aria-selected="false">
                                                            <img src="images/sedan.png" alt="Car Image">
                                                        </a>
                                                    </div><br>
                                                </div>

                                                <div class="col-md-6">
                                                    <iframe
                                                        src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d1773182.221176982!2d75.40930041836052!3d29.770512315577353!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x391a837462345a7d%3A0x681102348ec60610!2sLudhiana%2C%20Punjab!3m2!1d30.900965!2d75.8572758!4m5!1s0x390cfd3c113a7b05%3A0xf8913afee1665916!2sNew%20Delhi%20Railway%20Station%2C%20Bhavbhuti%20Marg%2C%20Ratan%20Lal%20Market%2C%20Kamla%20Market%2C%20Ajmeri%20Gate%2C%20New%20Delhi%2C%20Delhi!3m2!1d28.642891499999998!2d77.2190894!5e0!3m2!1sen!2sin!4v1594463226630!5m2!1sen!2sin"
                                                        width="100%" height="450" frameborder="0" style="border:0;"
                                                        allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </div>

                            </div>
                            <br>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- Search Section End here -->



    <div class="clearfix"></div>

@include('front.layout.footer')