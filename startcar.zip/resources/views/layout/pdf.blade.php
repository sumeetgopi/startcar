<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Order PDF</title>
</head>
<body>
  @yield('content')
</body>
</html>
