<?php 
    return [
        'created' => 'SMS template created successfully',
        'updated' => 'SMS template updated successfully',
    ];
?>