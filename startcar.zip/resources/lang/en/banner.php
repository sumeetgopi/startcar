<?php 
    return [
        'created' => 'Banner created successfully',
        'updated' => 'Banner updated successfully',
    ];
?>