<?php 
    return [
        'created' => 'Car Type created successfully',
        'updated' => 'Car Type updated successfully',
    ];
?>