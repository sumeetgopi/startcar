<?php 
    return [
        'created' => 'Sub Category created successfully',
        'updated' => 'Sub Category updated successfully',
    ];
?>