<?php 
    return [
        'created' => 'Category created successfully',
        'updated' => 'Category updated successfully',
    ];
?>