<?php 
    return [
        'created' => 'Coupon/cashback created successfully',
        'updated' => 'Coupon/cashback updated successfully',
    ];
?>