<?php 
    return [
        'send' => 'Notification send successfully',
    ];
?>