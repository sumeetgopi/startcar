<?php 
    return [
        'created' => 'Brand created successfully',
        'updated' => 'Brand updated successfully',
    ];
?>