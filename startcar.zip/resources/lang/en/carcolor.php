<?php 
    return [
        'created' => 'Color created successfully',
        'updated' => 'Color updated successfully',
    ];
?>