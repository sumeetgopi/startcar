<?php 
    return [
        'created' => 'Customer created successfully',
        'updated' => 'Customer updated successfully',
    ];
?>