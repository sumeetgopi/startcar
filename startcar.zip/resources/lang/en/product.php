<?php 
    return [
        'created' => 'Product created successfully',
        'updated' => 'Product updated successfully',
    ];
?>