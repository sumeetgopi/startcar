<?php 
    return [
        'created' => 'State created successfully',
        'updated' => 'State updated successfully',
    ];
?>