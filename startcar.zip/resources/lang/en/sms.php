<?php 
    return [
        'send' => 'SMS send successfully',
    ];
?>