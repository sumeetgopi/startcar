<?php 
    return [
        'created' => 'Unit created successfully',
        'updated' => 'Unit updated successfully',
    ];
?>