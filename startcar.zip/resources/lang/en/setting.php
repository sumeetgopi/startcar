<?php 
    return [
        'updated' => 'Setting updated successfully',
    ];
?>