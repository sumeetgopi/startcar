<?php 
    return [
        'created' => 'Order created successfully',
        'updated' => 'Order no <b>:order_number</b> is set to status <b>:order_status</b>',
    ];
?>